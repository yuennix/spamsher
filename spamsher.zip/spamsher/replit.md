# SPAMSHER - Facebook Auto-Sharing Tool

## Overview

SPAMSHER is an automated Facebook post sharing application designed for Termux (Android terminal emulator). The application enables users to share Facebook posts automatically using cookie-based authentication. It features a terminal-based interface with a red SPAMSHER ASCII banner.

The project is a command-line tool that integrates with Facebook Graph API to provide automated post sharing functionality through an interactive console menu system.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Application Architecture

**Terminal Interface**: Python console application with ANSI color support
- **Design Pattern**: Interactive menu-driven interface
- **Color Scheme**: Red banner with green/cyan/yellow status messages
- **Data Storage**: JSON-based account storage (accounts.json)

**Core Components**:
1. **termux_share.py**: Main application with FacebookShare class and AccountManager
2. **cookie_generator.py**: Standalone module for generating Facebook authentication cookies

**Rationale**: Terminal-based design provides lightweight operation suitable for Termux environments. JSON storage allows simple data persistence without database dependencies.

### Authentication Mechanism

**Facebook Authentication**: Cookie-based authentication using Facebook's business.facebook.com endpoints
- Extracts access tokens from Facebook Business Manager pages
- Supports both manual cookie input and credential-based cookie generation
- Uses standard browser headers to mimic legitimate requests

**Security Considerations**: 
- Session secret stored as environment variable
- No persistent storage of credentials (cookies provided by user)
- Educational/demonstration purposes only (as noted in README)

### Facebook Graph API Integration

**Token Extraction**: 
- Scrapes access token from Facebook Business Manager HTML response
- Pattern: `EAAG` prefix followed by token string extraction via regex
- Headers include Chrome 107 user-agent and security headers for authenticity

**Post Sharing**:
- Uses Facebook Graph API endpoints (incomplete in provided code)
- Configurable share count and delay between shares
- Progress tracking and status updates

**Alternatives Considered**: Official Facebook SDK was likely avoided to maintain simplicity and reduce dependencies, though this approach is more fragile to Facebook UI changes.

### Deployment Architecture

**Production Server**: Gunicorn WSGI server
- Configuration: `--bind 0.0.0.0:5000 --reuse-port`
- Supports concurrent requests with worker process reuse

**Replit Environment**:
- Development server: Flask development server on port 5000
- Configured workflow: `python main.py` with webview output
- Deployment: Autoscale deployment using Gunicorn
- Port configuration: Flask app binds to `0.0.0.0:5000` to work with Replit's proxy

**Target Platform**: Originally designed for Render.com free tier
- Build command: `pip install -r requirements.txt`
- Port binding via environment variable

**Rationale**: Gunicorn provides production-grade WSGI serving with minimal configuration. The Flask app is configured to bind to 0.0.0.0 to work properly with Replit's iframe-based preview system.

### Termux/Mobile Support

**Standalone Script**: termux_share.py provides CLI-based alternative
- JSON-based account storage (accounts.json)
- ANSI color terminal interface with ASCII banner
- Multi-account bulk operations support

**Rationale**: Termux script enables Android users to run the tool without web hosting, useful for users who prefer command-line interfaces or have limited connectivity.

## External Dependencies

### Python Packages

**Core Framework**:
- `flask==3.0.2` - Web application framework
- `flask-sqlalchemy==3.1.1` - SQL toolkit (included but not actively used in provided code)
- `gunicorn==23.0.0` - Production WSGI server

**HTTP & Web Scraping**:
- `requests==2.31.0` - HTTP library for API calls and cookie generation
- `beautifulsoup4==4.12.2` - HTML parsing for cookie extraction
- `httpx` - Async HTTP client (listed but not used in provided code)
- `trafilatura` - Web scraping utility (listed but not used in provided code)

**Database**:
- `psycopg2-binary==2.9.9` - PostgreSQL adapter (listed but no database usage in provided code)

**Validation**:
- `email-validator==2.1.0.post1` - Email validation utilities

**Note**: Several dependencies appear unused in the current codebase (SQLAlchemy, PostgreSQL, httpx, trafilatura), suggesting either planned features or legacy inclusions that should be cleaned up.

### Frontend Libraries (CDN)

**UI Framework**:
- Bootstrap 5.3.0 - Responsive layout and components
- Font Awesome 6.4.0 - Icon library

**Animation & Effects**:
- GSAP 3.12.2 + ScrollTrigger - Advanced animations and scroll effects
- Three.js 0.152.2 - 3D graphics rendering

**Rationale**: CDN delivery reduces bundle size and leverages browser caching, though it introduces external dependencies that could affect offline functionality.

### Third-Party APIs

**Facebook Graph API**:
- Authentication endpoint: `https://business.facebook.com/content_management`
- Graph API endpoints: `https://b-graph.facebook.com` (referenced in attached Streamlit code)
- Token format: `EAAG` prefixed access tokens

**Authentication Flow**:
1. User provides Facebook cookie or credentials
2. Application extracts/generates access token from Business Manager
3. Token used to make Graph API calls for post sharing

**Rate Limiting**: Not implemented in current code; Facebook may impose rate limits

**Error Handling**: Basic try-catch blocks; cookie blocking detected but not gracefully handled

### Environment Configuration

**Required Variables**:
- `SESSION_SECRET` - Flask session encryption key (falls back to "dev-secret-key" if not set)
  - For Replit: Set in the Secrets tab or environment variables
  - For production: Should be a strong random string (32+ characters)

**Optional Variables**:
- `PORT` - Server port for deployment (defaults to 5000 in development)

### Replit Setup (November 16, 2025)

**Installation**:
1. Python 3.11 installed via programming_language_install_tool
2. Dependencies installed from requirements.txt (requests, beautifulsoup4)
3. Workflow configured to run Termux script in console mode

**Running the Application**:
- The workflow automatically runs `python termux_share.py`
- Interactive console menu with red SPAMSHER banner
- No web interface - terminal-only application
- Account data stored in `accounts.json` file

**Features**:
1. Get Cookie (Bulk Extract) - Extract cookies from uid|password credentials
2. Share Post (Single Account) - Share posts using one account
3. Share Post (All Accounts) - Share posts using all stored accounts
4. List Accounts - View all stored account information
5. Add Account (Manual Cookie) - Manually add account cookies