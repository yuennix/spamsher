# SpamSher - Termux Edition

## Quick Start Guide

### Installation (Termux)
```bash
# Update packages
pkg update && pkg upgrade

# Install Python and dependencies
pkg install python git
pip install requests

# Download script
curl -O <your-script-url>/termux_share.py
chmod +x termux_share.py

# Run
python termux_share.py
```

## Features

### 1. Get Cookie (Bulk Extract)
Extract Facebook cookies from uid|password credentials in bulk.

**How to use:**
1. Select option `[1]` from main menu
2. Paste your credentials in format: `uid|password`
3. You can paste multiple lines
4. Press Enter twice when done
5. Script will process each account
6. Save extracted cookies to file when prompted

**Example:**
```
61583976865279|konorpogi
61583607248702|konorpogi
```

**Output:**
```
[1/2] 61583976865279... ✓ Invalid username or password (401)
[2/2] 61583607248702... ✓

Total:2 Success:1 Failed:1

Save? (y/n): y
Filename: my_cookies.txt
[✓] Saved 1 successful cookie(s) to my_cookies.txt
```

### 2. Share Post (Single Account)
Share a Facebook post using one stored account.

**Steps:**
1. Select option `[2]`
2. Choose account from list
3. Enter Facebook post URL
4. Enter share count (how many times to share)
5. Enter delay between shares in seconds

### 3. Share Post (All Accounts)
Share a Facebook post using ALL stored accounts at once.

**Steps:**
1. Select option `[3]`
2. Enter Facebook post URL
3. Enter share count per account
4. Enter delay between shares
5. Script will use all accounts automatically

### 4. List Accounts
View all stored accounts with their status.

### 5. Add Account (Manual Cookie)
Manually add an account using a Facebook cookie.

## Features Summary

✓ **WEYN-style interface** - Beautiful ASCII art banner
✓ **Bulk cookie extraction** - Extract multiple accounts at once using uid|password
✓ **Account storage** - Saves accounts to accounts.json
✓ **Multi-account sharing** - Share posts across all accounts
✓ **Progress tracking** - See extraction/share progress in real-time
✓ **Full cookie export** - Save extracted cookies to files
✓ **Error handling** - Clear error messages for failed operations

## How to Get uid|password

### Method 1: Your Facebook Info
- **uid** = Your Facebook User ID (the number in your profile URL)
- **password** = Your Facebook password

### Method 2: Find User ID
1. Go to your Facebook profile
2. Look at URL: `facebook.com/profile.php?id=61583976865279`
3. The number is your UID

## Important Notes

⚠️ **Security:**
- Never share your cookies or passwords
- Keep `accounts.json` and saved cookie files secure
- Don't run on untrusted devices

⚠️ **Facebook Limits:**
- Don't share too frequently (use delays)
- Facebook may block accounts that abuse sharing
- Use realistic delays (2-5 seconds minimum)

⚠️ **Legal:**
- For educational purposes only
- Use responsibly
- Follow Facebook's Terms of Service

## Troubleshooting

### "Invalid username or password (401)"
- Check if uid|password format is correct
- Verify your Facebook credentials
- Account may be checkpointed

### "Failed to get token"
- Cookie may have expired
- Extract fresh cookies
- Check if account is restricted

### Script won't run
- Install dependencies: `pip install requests`
- Check Python version: `python --version` (needs 3.6+)
- Make script executable: `chmod +x termux_share.py`

## File Structure

```
termux_share.py     # Main script
accounts.json       # Stored accounts (auto-created)
cookies.txt         # Exported cookies (when you save)
```

## Support

For issues, questions, or updates:
- Check the web interface at your Replit URL
- Use the web version for more features

---

**Disclaimer**: This tool is for educational purposes only. Use responsibly and respect Facebook's Terms of Service.
