#!/usr/bin/env python3
import os
import sys
import json
import time
import re
import requests
from datetime import datetime

# Color codes
RED = "\033[1;31m"
GREEN = "\033[1;32m"
YELLOW = "\033[1;33m"
BLUE = "\033[1;34m"
CYAN = "\033[1;36m"
MAGENTA = "\033[1;35m"
WHITE = "\033[1;37m"
RESET = "\033[0m"

BANNER = f"""{RED}
███████╗██████╗  █████╗ ███╗   ███╗███████╗██╗  ██╗███████╗██████╗ 
██╔════╝██╔══██╗██╔══██╗████╗ ████║██╔════╝██║  ██║██╔════╝██╔══██╗
███████╗██████╔╝███████║██╔████╔██║███████╗███████║███████╗██████╔╝
╚════██║██╔═══╝ ██╔══██║██║╚██╔╝██║╚════██║██╔══██║██╔════╝██╔══██╗
███████║██║     ██║  ██║██║ ╚═╝ ██║███████║██║  ██║███████╗██║  ██║
╚══════╝╚═╝     ╚═╝  ╚═╝╚═╝     ╚═╝╚══════╝╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝
{GREEN}════════════════════════════════════════════════════════════════
{RESET}{CYAN}[ FACEBOOK AUTO SHARE TOOL ]
{MAGENTA}[ TERMUX EDITION ]
{GREEN}════════════════════════════════════════════════════════════════
{RESET}"""

ACCOUNTS_FILE = "accounts.json"

class FacebookShare:
    @staticmethod
    def get_cookie_from_credentials(uid, password):
        """Extract cookie from uid|password"""
        try:
            session = requests.Session()
            headers = {
                'user-agent': "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36"
            }
            
            print(f"{YELLOW}[*] Getting login page...{RESET}")
            getlog = session.get(f'https://m.facebook.com/login/device-based/password/?uid={uid}&flow=login_no_pin')
            
            try:
                idpass = {
                    "lsd": re.search('name="lsd" value="(.*?)"', str(getlog.text)).group(1),
                    "jazoest": re.search('name="jazoest" value="(.*?)"', str(getlog.text)).group(1),
                    "uid": uid,
                    "next": "https://m.facebook.com/login/save-device/",
                    "flow": "login_no_pin",
                    "pass": password,
                }
            except:
                return None, "Failed to extract login form data"
            
            print(f"{YELLOW}[*] Attempting login...{RESET}")
            login = session.post("https://m.facebook.com/login/device-based/regular/login/?shbl=1", 
                               headers=headers, data=idpass, allow_redirects=False)
            
            cookies = session.cookies.get_dict()
            if "c_user" in cookies:
                cookie_str = ";".join([f"{k}={v}" for k, v in cookies.items()])
                return cookie_str, None
            elif "checkpoint" in cookies:
                return None, "Account checkpoint"
            else:
                return None, "Invalid username or password"
                
        except Exception as e:
            return None, f"Error: {str(e)}"
    
    @staticmethod
    def get_token(cookie):
        try:
            headers = {
                'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/107.0.0.0 Safari/537.36',
                'sec-ch-ua': '"Google Chrome";v="107", "Chromium";v="107", "Not=A?Brand";v="24"',
                'sec-ch-ua-mobile': '?0',
                'sec-ch-ua-platform': "Windows",
                'sec-fetch-dest': 'document',
                'sec-fetch-mode': 'navigate',
                'sec-fetch-site': 'none',
                'sec-fetch-user': '?1',
                'upgrade-insecure-requests': '1',
                'cookie': cookie
            }
            
            response = requests.get('https://business.facebook.com/content_management', headers=headers, timeout=30)
            data = response.text
            
            token_match = re.search('EAAG(.*?)","', data)
            if not token_match:
                print(f"{RED}[✗] Could not find token in response. Cookie may be expired.{RESET}")
                return None, None
                
            access_token = 'EAAG' + token_match.group(1)
            return access_token, headers['cookie']
        except requests.exceptions.Timeout:
            print(f"{RED}[✗] Request timeout. Check your internet connection.{RESET}")
            return None, None
        except Exception as e:
            print(f"{RED}[✗] Token error: {str(e)}{RESET}")
            return None, None
    
    @staticmethod
    def share_post(cookie, post_url, token, count=1, delay=0):
        headers = {
            "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/107.0.0.0 Safari/537.36",
            "cookie": cookie,
            "accept": "application/json",
            "content-type": "application/x-www-form-urlencoded",
        }
        
        success_count = 0
        post_id = None
        
        try:
            if '/posts/' in post_url:
                post_id = post_url.split('/posts/')[-1].split('?')[0]
            elif '/share/' in post_url:
                share_id = post_url.split('/share/')[-1].split('?')[0].rstrip('/')
                try:
                    decode_response = requests.get(f'https://graph.facebook.com/v18.0/{share_id}?access_token={token}')
                    if decode_response.status_code == 200:
                        data = decode_response.json()
                        post_id = data.get('id')
                except:
                    pass
            elif '/photo' in post_url or '/video' in post_url:
                parts = post_url.split('/')
                for i, part in enumerate(parts):
                    if part in ['photo.php', 'video.php', 'photo', 'video']:
                        if 'fbid=' in post_url:
                            fbid = post_url.split('fbid=')[1].split('&')[0]
                            post_id = fbid
                        break
            
            if not post_id:
                print(f"{RED}[✗] Could not extract post ID from URL{RESET}")
                return 0
                
        except Exception as e:
            print(f"{RED}[✗] Error parsing URL: {str(e)}{RESET}")
            return 0
        
        share_endpoint = f'https://graph.facebook.com/v18.0/{post_id}/sharedposts?access_token={token}'
        
        for i in range(count):
            print(f"{YELLOW}[{i+1}/{count}] Sharing post {post_id}...{RESET}")
            
            if delay > 0 and i > 0:
                time.sleep(delay)
                
            try:
                post_data = {}
                response = requests.post(share_endpoint, headers=headers, data=post_data, timeout=30)
                
                try:
                    data = response.json()
                except:
                    print(f"{RED}[✗] Invalid response: {response.text[:100]}{RESET}")
                    break
                    
                if 'id' in data:
                    success_count += 1
                    print(f"{GREEN}[✓] Share {i+1}/{count} successful!{RESET}")
                elif 'error' in data:
                    error_msg = data.get('error', {}).get('message', 'Unknown error')
                    error_code = data.get('error', {}).get('code', 'N/A')
                    print(f"{RED}[✗] FB Error ({error_code}): {error_msg}{RESET}")
                    if i == 0:
                        break
                else:
                    print(f"{RED}[✗] Share failed: {str(data)[:100]}{RESET}")
                    break
                    
            except requests.exceptions.Timeout:
                print(f"{RED}[✗] Request timeout{RESET}")
                break
            except Exception as e:
                print(f"{RED}[✗] Error: {str(e)}{RESET}")
                break
                
        return success_count

class AccountManager:
    @staticmethod
    def load_accounts():
        if os.path.exists(ACCOUNTS_FILE):
            try:
                with open(ACCOUNTS_FILE, 'r') as f:
                    return json.load(f)
            except:
                return []
        return []
    
    @staticmethod
    def save_accounts(accounts):
        with open(ACCOUNTS_FILE, 'w') as f:
            json.dump(accounts, f, indent=2)
    
    @staticmethod
    def add_account(name, cookie, token=None):
        accounts = AccountManager.load_accounts()
        account = {
            'name': name,
            'cookie': cookie,
            'token': token,
            'added_date': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            'status': 'active'
        }
        accounts.append(account)
        AccountManager.save_accounts(accounts)
        print(f"{GREEN}[✓] Account '{name}' added successfully!{RESET}")
    
    @staticmethod
    def list_accounts():
        accounts = AccountManager.load_accounts()
        if not accounts:
            print(f"{YELLOW}[!] No accounts stored.{RESET}")
            return
        
        print(f"\n{CYAN}=== STORED ACCOUNTS ==={RESET}")
        for idx, acc in enumerate(accounts, 1):
            status_color = GREEN if acc.get('status') == 'active' else RED
            print(f"{idx}. {acc['name']} | Added: {acc['added_date']} | {status_color}{acc.get('status', 'unknown')}{RESET}")
    
    @staticmethod
    def extract_bulk():
        print(f"\n{CYAN}Extract Accounts{RESET}")
        print(f"{YELLOW}Format: uid|password OR uid|access_token{RESET}")
        print(f"{YELLOW}Paste credentials (Enter twice to finish):{RESET}\n")
        
        credentials = []
        
        while True:
            try:
                line = input().strip()
                if not line:
                    if credentials:
                        break
                    continue
                credentials.append(line)
            except:
                break
        
        if not credentials:
            print(f"{RED}[!] No credentials provided{RESET}")
            return
        
        success = 0
        failed = 0
        results = []
        
        for idx, cred in enumerate(credentials, 1):
            if '|' not in cred:
                print(f"{RED}[{idx}/{len(credentials)}] Invalid format (use uid|password or uid|token){RESET}")
                failed += 1
                continue
            
            parts = cred.split('|', 1)
            uid = parts[0].strip()
            second_part = parts[1].strip()
            
            print(f"{YELLOW}[{idx}/{len(credentials)}] {uid}...{RESET}", end=' ')
            
            if second_part.startswith('EAA') and len(second_part) > 50:
                access_token = second_part
                dummy_cookie = f"c_user={uid};xs=dummy"
                print(f"{GREEN}✓ (Direct Token){RESET}")
                success += 1
                results.append({'uid': uid, 'cookie': dummy_cookie, 'token': access_token})
                AccountManager.add_account(f"Account_{uid}", dummy_cookie, access_token)
            else:
                password = second_part
                cookie, error = FacebookShare.get_cookie_from_credentials(uid, password)
                
                if cookie:
                    print(f"{GREEN}✓ (Cookie){RESET}")
                    success += 1
                    results.append({'uid': uid, 'cookie': cookie, 'token': None})
                    AccountManager.add_account(f"Account_{uid}", cookie)
                else:
                    print(f"{RED}✗ {error}{RESET}")
                    failed += 1
        
        print(f"\n{GREEN}Total:{len(credentials)} Success:{success} Failed:{failed}{RESET}")
        
        if success > 0:
            save_choice = input(f"\n{CYAN}Save to file? (y/n): {RESET}").lower()
            if save_choice == 'y':
                filename = input(f"{CYAN}Filename (default: accounts.txt): {RESET}").strip() or "accounts.txt"
                with open(filename, 'w') as f:
                    for r in results:
                        if r.get('token'):
                            f.write(f"{r['uid']}|{r['token']}\n")
                        else:
                            f.write(f"{r['cookie']}\n")
                print(f"{GREEN}[✓] Saved {success} account(s) to {filename}{RESET}")
        elif failed > 0:
            print(f"{YELLOW}[!] No successful extractions to save{RESET}")

def clear():
    os.system('clear' if os.name != 'nt' else 'cls')

def main_menu():
    clear()
    print(BANNER)
    print(f"{CYAN}[1]{RESET} Extract Accounts (uid|password OR uid|token)")
    print(f"{CYAN}[2]{RESET} Share Post (Single Account)")
    print(f"{CYAN}[3]{RESET} Share Post (All Accounts)")
    print(f"{CYAN}[4]{RESET} List Accounts")
    print(f"{CYAN}[5]{RESET} Add Account (Manual Cookie)")
    print(f"{CYAN}[6]{RESET} Remove Dead Accounts")
    print(f"{CYAN}[0]{RESET} Exit")
    
    choice = input(f"\n{GREEN}Select option: {RESET}").strip()
    return choice

def share_with_account():
    accounts = AccountManager.load_accounts()
    if not accounts:
        print(f"{RED}[!] No accounts available. Extract accounts first.{RESET}")
        input(f"\n{YELLOW}Press Enter to continue...{RESET}")
        return
    
    print(f"\n{CYAN}=== SELECT ACCOUNT ==={RESET}")
    for idx, acc in enumerate(accounts, 1):
        print(f"{idx}. {acc['name']}")
    
    try:
        selection = int(input(f"\n{GREEN}Select account number: {RESET}").strip())
        if selection < 1 or selection > len(accounts):
            print(f"{RED}[✗] Invalid selection{RESET}")
            return
        
        account = accounts[selection - 1]
        post_url = input(f"{CYAN}Post URL: {RESET}").strip()
        count = int(input(f"{CYAN}Share count: {RESET}").strip() or "1")
        delay = float(input(f"{CYAN}Delay (seconds): {RESET}").strip() or "0")
        
        if account.get('token'):
            print(f"\n{YELLOW}[*] Using stored access token...{RESET}")
            token = account['token']
            cookie = account['cookie']
            print(f"{GREEN}[✓] Token ready!{RESET}\n")
        else:
            print(f"\n{YELLOW}[*] Extracting access token from cookie...{RESET}")
            token, cookie = FacebookShare.get_token(account['cookie'])
            
            if not token:
                print(f"{RED}[✗] Failed to get token. Cookie may be invalid or expired.{RESET}")
                return
            
            print(f"{GREEN}[✓] Token obtained!{RESET}\n")
        
        success = FacebookShare.share_post(cookie, post_url, token, count, delay)
        print(f"\n{GREEN}[✓] Completed! {success}/{count} shares successful{RESET}")
        
    except ValueError:
        print(f"{RED}[✗] Invalid input{RESET}")
    
    input(f"\n{YELLOW}Press Enter to continue...{RESET}")

def share_with_all():
    accounts = AccountManager.load_accounts()
    if not accounts:
        print(f"{RED}[!] No accounts available.{RESET}")
        input(f"\n{YELLOW}Press Enter to continue...{RESET}")
        return
    
    post_url = input(f"{CYAN}Post URL: {RESET}").strip()
    count = int(input(f"{CYAN}Share count per account: {RESET}").strip() or "1")
    delay = float(input(f"{CYAN}Delay (seconds): {RESET}").strip() or "0")
    
    total_success = 0
    for idx, account in enumerate(accounts, 1):
        print(f"\n{CYAN}[*] Account {idx}/{len(accounts)}: {account['name']}{RESET}")
        
        if account.get('token'):
            print(f"{YELLOW}    Using stored token...{RESET}")
            token = account['token']
            cookie = account['cookie']
        else:
            print(f"{YELLOW}    Extracting token from cookie...{RESET}")
            token, cookie = FacebookShare.get_token(account['cookie'])
            if not token:
                print(f"{RED}[✗] Failed to get token for {account['name']}{RESET}")
                continue
        
        success = FacebookShare.share_post(cookie, post_url, token, count, delay)
        total_success += success
    
    print(f"\n{GREEN}[✓] All done! Total: {total_success} shares{RESET}")
    input(f"\n{YELLOW}Press Enter to continue...{RESET}")

def remove_dead_accounts():
    accounts = AccountManager.load_accounts()
    if not accounts:
        print(f"{RED}[!] No accounts to check.{RESET}")
        input(f"\n{YELLOW}Press Enter to continue...{RESET}")
        return
    
    print(f"\n{CYAN}=== CHECKING ACCOUNTS ==={RESET}")
    print(f"{YELLOW}Testing {len(accounts)} account(s)...{RESET}\n")
    
    alive = []
    dead = []
    
    for idx, account in enumerate(accounts, 1):
        print(f"{YELLOW}[{idx}/{len(accounts)}] {account['name']}...{RESET}", end=' ')
        
        if account.get('token'):
            token = account['token']
            try:
                test_response = requests.get(f'https://graph.facebook.com/v18.0/me?access_token={token}', timeout=10)
                if test_response.status_code == 200:
                    data = test_response.json()
                    if 'id' in data:
                        print(f"{GREEN}✓ Alive{RESET}")
                        alive.append(account)
                    else:
                        print(f"{RED}✗ Dead (Invalid token){RESET}")
                        dead.append(account)
                else:
                    print(f"{RED}✗ Dead (Status {test_response.status_code}){RESET}")
                    dead.append(account)
            except:
                print(f"{RED}✗ Dead (Connection error){RESET}")
                dead.append(account)
        else:
            token, _ = FacebookShare.get_token(account['cookie'])
            if token:
                try:
                    test_response = requests.get(f'https://graph.facebook.com/v18.0/me?access_token={token}', timeout=10)
                    if test_response.status_code == 200:
                        data = test_response.json()
                        if 'id' in data:
                            print(f"{GREEN}✓ Alive{RESET}")
                            alive.append(account)
                        else:
                            print(f"{RED}✗ Dead (Invalid){RESET}")
                            dead.append(account)
                    else:
                        print(f"{RED}✗ Dead (Status {test_response.status_code}){RESET}")
                        dead.append(account)
                except:
                    print(f"{RED}✗ Dead (Connection error){RESET}")
                    dead.append(account)
            else:
                print(f"{RED}✗ Dead (Cookie expired){RESET}")
                dead.append(account)
    
    print(f"\n{CYAN}=== RESULTS ==={RESET}")
    print(f"{GREEN}Alive: {len(alive)}{RESET}")
    print(f"{RED}Dead: {len(dead)}{RESET}")
    
    if dead:
        print(f"\n{YELLOW}Dead accounts:{RESET}")
        for acc in dead:
            print(f"  - {acc['name']}")
        
        confirm = input(f"\n{RED}Remove {len(dead)} dead account(s)? (y/n): {RESET}").lower()
        if confirm == 'y':
            AccountManager.save_accounts(alive)
            print(f"{GREEN}[✓] Removed {len(dead)} dead account(s)!{RESET}")
        else:
            print(f"{YELLOW}[!] No accounts removed{RESET}")
    else:
        print(f"\n{GREEN}[✓] All accounts are alive!{RESET}")
    
    input(f"\n{YELLOW}Press Enter to continue...{RESET}")

def main():
    while True:
        choice = main_menu()
        
        if choice == '1':
            AccountManager.extract_bulk()
            input(f"\n{YELLOW}Press Enter to continue...{RESET}")
        elif choice == '2':
            share_with_account()
        elif choice == '3':
            share_with_all()
        elif choice == '4':
            AccountManager.list_accounts()
            input(f"\n{YELLOW}Press Enter to continue...{RESET}")
        elif choice == '5':
            name = input(f"{CYAN}Account name: {RESET}").strip()
            cookie = input(f"{CYAN}Cookie: {RESET}").strip()
            if name and cookie:
                AccountManager.add_account(name, cookie)
            else:
                print(f"{RED}[✗] Name and cookie required{RESET}")
            input(f"\n{YELLOW}Press Enter to continue...{RESET}")
        elif choice == '6':
            remove_dead_accounts()
        elif choice == '0':
            print(f"\n{CYAN}Goodbye!{RESET}\n")
            break
        else:
            print(f"{RED}[✗] Invalid option{RESET}")
            input(f"\n{YELLOW}Press Enter to continue...{RESET}")

if __name__ == '__main__':
    try:
        main()
    except KeyboardInterrupt:
        print(f"\n\n{RED}[!] Interrupted{RESET}")
        sys.exit(0)
