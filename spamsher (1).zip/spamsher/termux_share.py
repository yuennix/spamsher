#!/usr/bin/env python3
import os
import sys
import json
import time
import re
import requests
from datetime import datetime
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.chrome.service import Service
from selenium.common.exceptions import TimeoutException, NoSuchElementException
import undetected_chromedriver as uc

# Color codes
RED = "\033[1;31m"
GREEN = "\033[1;32m"
YELLOW = "\033[1;33m"
BLUE = "\033[1;34m"
CYAN = "\033[1;36m"
MAGENTA = "\033[1;35m"
WHITE = "\033[1;37m"
RESET = "\033[0m"

BANNER = f"""{RED}
███████╗██████╗  █████╗ ███╗   ███╗███████╗██╗  ██╗███████╗██████╗ 
██╔════╝██╔══██╗██╔══██╗████╗ ████║██╔════╝██║  ██║██╔════╝██╔══██╗
███████╗██████╔╝███████║██╔████╔██║███████╗███████║███████╗██████╔╝
╚════██║██╔═══╝ ██╔══██║██║╚██╔╝██║╚════██║██╔══██║██╔════╝██╔══██╗
███████║██║     ██║  ██║██║ ╚═╝ ██║███████║██║  ██║███████╗██║  ██║
╚══════╝╚═╝     ╚═╝  ╚═╝╚═╝     ╚═╝╚══════╝╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝
{GREEN}════════════════════════════════════════════════════════════════
{RESET}{CYAN}[ FACEBOOK AUTO SHARE TOOL ]
{MAGENTA}[ TERMUX EDITION ]
{GREEN}════════════════════════════════════════════════════════════════
{RESET}"""

ACCOUNTS_FILE = "accounts.json"

class FacebookShare:
    @staticmethod
    def get_cookie_from_credentials(uid, password):
        """Extract cookie from uid|password"""
        try:
            session = requests.Session()
            headers = {
                'user-agent': "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36"
            }
            
            print(f"{YELLOW}[*] Getting login page...{RESET}")
            getlog = session.get(f'https://m.facebook.com/login/device-based/password/?uid={uid}&flow=login_no_pin')
            
            try:
                lsd_match = re.search('name="lsd" value="(.*?)"', str(getlog.text))
                jazoest_match = re.search('name="jazoest" value="(.*?)"', str(getlog.text))
                
                if not lsd_match or not jazoest_match:
                    return None, "Failed to extract login form data"
                
                idpass = {
                    "lsd": lsd_match.group(1),
                    "jazoest": jazoest_match.group(1),
                    "uid": uid,
                    "next": "https://m.facebook.com/login/save-device/",
                    "flow": "login_no_pin",
                    "pass": password,
                }
            except Exception as e:
                return None, f"Failed to extract login form data: {str(e)}"
            
            print(f"{YELLOW}[*] Attempting login...{RESET}")
            login = session.post("https://m.facebook.com/login/device-based/regular/login/?shbl=1", 
                               headers=headers, data=idpass, allow_redirects=False)
            
            cookies = session.cookies.get_dict()
            if "c_user" in cookies:
                cookie_str = ";".join([f"{k}={v}" for k, v in cookies.items()])
                return cookie_str, None
            elif "checkpoint" in cookies:
                return None, "Account checkpoint"
            else:
                return None, "Invalid username or password"
                
        except Exception as e:
            return None, f"Error: {str(e)}"
    
    @staticmethod
    def get_token(cookie):
        try:
            headers = {
                'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/107.0.0.0 Safari/537.36',
                'sec-ch-ua': '"Google Chrome";v="107", "Chromium";v="107", "Not=A?Brand";v="24"',
                'sec-ch-ua-mobile': '?0',
                'sec-ch-ua-platform': "Windows",
                'sec-fetch-dest': 'document',
                'sec-fetch-mode': 'navigate',
                'sec-fetch-site': 'none',
                'sec-fetch-user': '?1',
                'upgrade-insecure-requests': '1',
                'cookie': cookie
            }
            
            urls_to_try = [
                'https://business.facebook.com/content_management',
                'https://business.facebook.com/creatorstudio',
                'https://www.facebook.com/me'
            ]
            
            access_token = None
            for url in urls_to_try:
                try:
                    response = requests.get(url, headers=headers, timeout=30)
                    data = response.text
                    
                    token_patterns = [
                        r'EAAG(.*?)","',
                        r'EAAG(.*?)"',
                        r'"accessToken":"(EAAG[^"]+)"',
                        r'access_token=(EAAG[^&"]+)'
                    ]
                    
                    for pattern in token_patterns:
                        token_match = re.search(pattern, data)
                        if token_match:
                            if pattern.startswith('EAAG'):
                                access_token = 'EAAG' + token_match.group(1)
                            else:
                                access_token = token_match.group(1)
                            break
                    
                    if access_token:
                        return access_token, headers['cookie']
                except:
                    continue
            
            print(f"{RED}[✗] Could not find token. Cookie may be expired or invalid.{RESET}")
            return None, None
        except requests.exceptions.Timeout:
            print(f"{RED}[✗] Request timeout. Check your internet connection.{RESET}")
            return None, None
        except Exception as e:
            print(f"{RED}[✗] Token error: {str(e)}{RESET}")
            return None, None
    
    @staticmethod
    def create_browser(headless=True):
        """Create and configure Chrome browser instance"""
        try:
            options = uc.ChromeOptions()
            
            if headless:
                options.add_argument('--headless=new')
            
            options.add_argument('--no-sandbox')
            options.add_argument('--disable-dev-shm-usage')
            options.add_argument('--disable-blink-features=AutomationControlled')
            options.add_argument('--disable-gpu')
            options.add_argument('--window-size=1920,1080')
            options.add_argument('--user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36')
            
            # Suppress logging
            options.add_argument('--log-level=3')
            options.add_experimental_option('excludeSwitches', ['enable-logging'])
            
            driver = uc.Chrome(options=options, use_subprocess=False)
            driver.set_page_load_timeout(30)
            return driver
        except Exception as e:
            print(f"{RED}[✗] Failed to create browser: {str(e)}{RESET}")
            return None
    
    @staticmethod
    def inject_cookies(driver, cookie_string):
        """Inject cookies into browser session"""
        try:
            # Navigate to Facebook first to set domain
            driver.get("https://www.facebook.com")
            time.sleep(2)
            
            # Parse and inject cookies
            cookies = cookie_string.split(';')
            for cookie in cookies:
                if '=' in cookie:
                    parts = cookie.strip().split('=', 1)
                    name = parts[0].strip()
                    value = parts[1].strip() if len(parts) > 1 else ''
                    
                    try:
                        driver.add_cookie({
                            'name': name,
                            'value': value,
                            'domain': '.facebook.com'
                        })
                    except:
                        pass
            
            return True
        except Exception as e:
            print(f"{RED}[✗] Cookie injection failed: {str(e)}{RESET}")
            return False
    
    @staticmethod
    def share_post(cookie, post_url, token=None, count=1, delay=6.0):
        """Share Facebook post using browser automation (creates REAL shares)"""
        success_count = 0
        driver = None
        
        print(f"{CYAN}[*] Initializing browser automation...{RESET}")
        
        try:
            # Create browser instance
            driver = FacebookShare.create_browser(headless=True)
            if not driver:
                return 0
            
            print(f"{GREEN}[✓] Browser created{RESET}")
            
            # Inject cookies for authentication
            print(f"{YELLOW}[*] Injecting authentication cookies...{RESET}")
            if not FacebookShare.inject_cookies(driver, cookie):
                print(f"{RED}[✗] Failed to inject cookies{RESET}")
                return 0
            
            print(f"{GREEN}[✓] Authenticated{RESET}")
            print(f"{CYAN}[*] Target: {post_url[:60]}...{RESET}")
            print(f"{CYAN}[*] Starting {count} shares with {delay}s delay{RESET}\n")
            
            for i in range(count):
                try:
                    print(f"{YELLOW}[{i+1}/{count}] Navigating to post...{RESET}", end=' ')
                    
                    # Navigate to the post
                    driver.get(post_url)
                    time.sleep(3)
                    
                    # Check if logged in (look for checkpoint or login page)
                    if "login" in driver.current_url or "checkpoint" in driver.current_url:
                        print(f"{RED}✗ Cookie expired or checkpoint{RESET}")
                        break
                    
                    print(f"{GREEN}✓{RESET} {YELLOW}Finding share button...{RESET}", end=' ')
                    
                    # Find and click share button using multiple selectors (locale-independent)
                    share_button = None
                    share_selectors = [
                        "//div[@aria-label='Share']",
                        "//div[contains(@aria-label, 'Share')]",
                        "//a[contains(@aria-label, 'Share')]",
                        "//div[@role='button' and contains(@aria-label, 'Share')]",
                        "//span[contains(text(), 'Share')]",
                        "//span[contains(text(), 'share')]",
                        "//div[@aria-label='Send this to friends or post it on your timeline.']"
                    ]
                    
                    for selector in share_selectors:
                        try:
                            share_button = WebDriverWait(driver, 10).until(
                                EC.element_to_be_clickable((By.XPATH, selector))
                            )
                            break
                        except:
                            continue
                    
                    if not share_button:
                        print(f"{RED}✗ Share button not found{RESET}")
                        continue
                    
                    print(f"{GREEN}✓{RESET} {YELLOW}Clicking share...{RESET}", end=' ')
                    
                    # Click share button
                    driver.execute_script("arguments[0].click();", share_button)
                    time.sleep(2)
                    
                    # Find and click "Share Now" or "Share" in the dialog
                    share_now_selectors = [
                        "//span[contains(text(), 'Share now')]",
                        "//span[contains(text(), 'Share Now')]",
                        "//div[@aria-label='Share now (Public)']",
                        "//div[@aria-label='Share now (Friends)']",
                        "//span[text()='Post']",
                        "//div[contains(@aria-label, 'Share now')]"
                    ]
                    
                    share_confirmed = False
                    for selector in share_now_selectors:
                        try:
                            share_now_button = WebDriverWait(driver, 10).until(
                                EC.element_to_be_clickable((By.XPATH, selector))
                            )
                            driver.execute_script("arguments[0].click();", share_now_button)
                            share_confirmed = True
                            break
                        except:
                            continue
                    
                    if not share_confirmed:
                        print(f"{RED}✗ Share confirmation button not found{RESET}")
                        continue
                    
                    # Wait for and verify share success confirmation
                    print(f"{GREEN}✓{RESET} {YELLOW}Verifying...{RESET}", end=' ')
                    time.sleep(4)
                    
                    # Look for SPECIFIC success confirmation text (NOT generic alerts)
                    # These patterns specifically indicate a successful share
                    success_patterns = [
                        "Post shared",
                        "post shared", 
                        "Shared to",
                        "shared to",
                        "You shared",
                        "you shared",
                        "Posted to your timeline",
                        "posted to your timeline"
                    ]
                    
                    share_verified = False
                    for pattern in success_patterns:
                        xpath = f"//*[contains(text(), '{pattern}')]"
                        try:
                            element = WebDriverWait(driver, 8).until(
                                EC.presence_of_element_located((By.XPATH, xpath))
                            )
                            # Verify element is actually visible
                            if element.is_displayed():
                                element_text = element.text.lower()
                                # Double-check the text actually contains success keywords
                                if any(word in element_text for word in ['share', 'post', 'timeline']):
                                    share_verified = True
                                    break
                        except:
                            continue
                    
                    # Only count as success if we got explicit share confirmation
                    if share_verified:
                        success_count += 1
                        print(f"{GREEN}✓ Share confirmed!{RESET}")
                    else:
                        print(f"{RED}✗ No share confirmation (failed or timed out){RESET}")
                    
                    # Wait before next share
                    if i < count - 1 and delay > 0:
                        time.sleep(delay)
                        
                except TimeoutException:
                    print(f"{RED}✗ Timeout waiting for elements{RESET}")
                    continue
                except Exception as e:
                    print(f"{RED}✗ Error: {str(e)[:50]}{RESET}")
                    continue
            
        except Exception as e:
            print(f"{RED}[✗] Browser automation error: {str(e)}{RESET}")
        finally:
            if driver:
                try:
                    driver.quit()
                    print(f"\n{CYAN}[*] Browser closed{RESET}")
                except:
                    pass
        
        return success_count

class AccountManager:
    @staticmethod
    def load_accounts():
        if os.path.exists(ACCOUNTS_FILE):
            try:
                with open(ACCOUNTS_FILE, 'r') as f:
                    return json.load(f)
            except:
                return []
        return []
    
    @staticmethod
    def save_accounts(accounts):
        with open(ACCOUNTS_FILE, 'w') as f:
            json.dump(accounts, f, indent=2)
    
    @staticmethod
    def add_account(name, cookie, token=None):
        accounts = AccountManager.load_accounts()
        account = {
            'name': name,
            'cookie': cookie,
            'token': token,
            'added_date': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            'status': 'active'
        }
        accounts.append(account)
        AccountManager.save_accounts(accounts)
        print(f"{GREEN}[✓] Account '{name}' added successfully!{RESET}")
    
    @staticmethod
    def list_accounts():
        accounts = AccountManager.load_accounts()
        if not accounts:
            print(f"{YELLOW}[!] No accounts stored.{RESET}")
            return
        
        print(f"\n{CYAN}=== STORED ACCOUNTS ==={RESET}")
        for idx, acc in enumerate(accounts, 1):
            status_color = GREEN if acc.get('status') == 'active' else RED
            print(f"{idx}. {acc['name']} | Added: {acc['added_date']} | {status_color}{acc.get('status', 'unknown')}{RESET}")
    
    @staticmethod
    def extract_bulk():
        print(f"\n{CYAN}Extract Accounts{RESET}")
        print(f"{YELLOW}Format: uid|password OR uid|access_token{RESET}")
        print(f"{YELLOW}Paste credentials (Enter twice to finish):{RESET}\n")
        
        credentials = []
        
        while True:
            try:
                line = input().strip()
                if not line:
                    if credentials:
                        break
                    continue
                credentials.append(line)
            except:
                break
        
        if not credentials:
            print(f"{RED}[!] No credentials provided{RESET}")
            return
        
        success = 0
        failed = 0
        results = []
        
        for idx, cred in enumerate(credentials, 1):
            if '|' not in cred:
                print(f"{RED}[{idx}/{len(credentials)}] Invalid format (use uid|password or uid|token){RESET}")
                failed += 1
                continue
            
            parts = cred.split('|', 1)
            uid = parts[0].strip()
            second_part = parts[1].strip()
            
            print(f"{YELLOW}[{idx}/{len(credentials)}] {uid}...{RESET}", end=' ')
            
            if second_part.startswith('EAA') and len(second_part) > 50:
                access_token = second_part
                dummy_cookie = f"c_user={uid};xs=dummy"
                print(f"{GREEN}✓ (Direct Token){RESET}")
                success += 1
                results.append({'uid': uid, 'cookie': dummy_cookie, 'token': access_token})
                AccountManager.add_account(f"Account_{uid}", dummy_cookie, access_token)
            else:
                password = second_part
                cookie, error = FacebookShare.get_cookie_from_credentials(uid, password)
                
                if cookie:
                    print(f"{GREEN}✓ (Cookie){RESET}")
                    success += 1
                    results.append({'uid': uid, 'cookie': cookie, 'token': None})
                    AccountManager.add_account(f"Account_{uid}", cookie)
                else:
                    print(f"{RED}✗ {error}{RESET}")
                    failed += 1
        
        print(f"\n{GREEN}Total:{len(credentials)} Success:{success} Failed:{failed}{RESET}")
        
        if success > 0:
            save_choice = input(f"\n{CYAN}Save to file? (y/n): {RESET}").lower()
            if save_choice == 'y':
                filename = input(f"{CYAN}Filename (default: accounts.txt): {RESET}").strip() or "accounts.txt"
                with open(filename, 'w') as f:
                    for r in results:
                        if r.get('token'):
                            f.write(f"{r['uid']}|{r['token']}\n")
                        else:
                            f.write(f"{r['cookie']}\n")
                print(f"{GREEN}[✓] Saved {success} account(s) to {filename}{RESET}")
        elif failed > 0:
            print(f"{YELLOW}[!] No successful extractions to save{RESET}")

def clear():
    os.system('clear' if os.name != 'nt' else 'cls')

def main_menu():
    clear()
    print(BANNER)
    print(f"{CYAN}[1]{RESET} Extract Accounts (uid|password OR uid|token)")
    print(f"{CYAN}[2]{RESET} Share Post (Single Account)")
    print(f"{CYAN}[3]{RESET} Share Post (All Accounts)")
    print(f"{CYAN}[4]{RESET} List Accounts")
    print(f"{CYAN}[5]{RESET} Add Account (Manual Cookie)")
    print(f"{CYAN}[6]{RESET} Remove Dead Accounts")
    print(f"{CYAN}[0]{RESET} Exit")
    
    choice = input(f"\n{GREEN}Select option: {RESET}").strip()
    return choice

def share_with_account():
    accounts = AccountManager.load_accounts()
    if not accounts:
        print(f"{RED}[!] No accounts available. Extract accounts first.{RESET}")
        input(f"\n{YELLOW}Press Enter to continue...{RESET}")
        return
    
    print(f"\n{CYAN}=== SELECT ACCOUNT ==={RESET}")
    for idx, acc in enumerate(accounts, 1):
        print(f"{idx}. {acc['name']}")
    
    try:
        selection = int(input(f"\n{GREEN}Select account number: {RESET}").strip())
        if selection < 1 or selection > len(accounts):
            print(f"{RED}[✗] Invalid selection{RESET}")
            return
        
        account = accounts[selection - 1]
        post_url = input(f"{CYAN}Post URL: {RESET}").strip()
        count = int(input(f"{CYAN}Share count: {RESET}").strip() or "1")
        delay_input = input(f"{CYAN}Delay between shares (seconds, default=6): {RESET}").strip()
        delay = float(delay_input) if delay_input else 6.0
        
        if account.get('token'):
            print(f"\n{YELLOW}[*] Using stored access token...{RESET}")
            token = account['token']
            cookie = account['cookie']
            print(f"{GREEN}[✓] Token ready!{RESET}\n")
        else:
            print(f"\n{YELLOW}[*] Extracting access token from cookie...{RESET}")
            token, cookie = FacebookShare.get_token(account['cookie'])
            
            if not token:
                print(f"{RED}[✗] Failed to get token. Cookie may be invalid or expired.{RESET}")
                return
            
            print(f"{GREEN}[✓] Token obtained!{RESET}\n")
        
        success = FacebookShare.share_post(cookie, post_url, token, count, delay)
        print(f"\n{GREEN}[✓] Completed! {success}/{count} shares successful{RESET}")
        
    except ValueError:
        print(f"{RED}[✗] Invalid input{RESET}")
    
    input(f"\n{YELLOW}Press Enter to continue...{RESET}")

def share_with_all():
    accounts = AccountManager.load_accounts()
    if not accounts:
        print(f"{RED}[!] No accounts available.{RESET}")
        input(f"\n{YELLOW}Press Enter to continue...{RESET}")
        return
    
    post_url = input(f"{CYAN}Post URL: {RESET}").strip()
    count = int(input(f"{CYAN}Share count per account: {RESET}").strip() or "1")
    delay_input = input(f"{CYAN}Delay between shares (seconds, default=6): {RESET}").strip()
    delay = float(delay_input) if delay_input else 6.0
    
    total_success = 0
    for idx, account in enumerate(accounts, 1):
        print(f"\n{CYAN}[*] Account {idx}/{len(accounts)}: {account['name']}{RESET}")
        
        if account.get('token'):
            print(f"{YELLOW}    Using stored token...{RESET}")
            token = account['token']
            cookie = account['cookie']
        else:
            print(f"{YELLOW}    Extracting token from cookie...{RESET}")
            token, cookie = FacebookShare.get_token(account['cookie'])
            if not token:
                print(f"{RED}[✗] Failed to get token for {account['name']}{RESET}")
                continue
        
        success = FacebookShare.share_post(cookie, post_url, token, count, delay)
        total_success += success
    
    print(f"\n{GREEN}[✓] All done! Total: {total_success} shares{RESET}")
    input(f"\n{YELLOW}Press Enter to continue...{RESET}")

def remove_dead_accounts():
    accounts = AccountManager.load_accounts()
    if not accounts:
        print(f"{RED}[!] No accounts to check.{RESET}")
        input(f"\n{YELLOW}Press Enter to continue...{RESET}")
        return
    
    print(f"\n{CYAN}=== CHECKING ACCOUNTS ==={RESET}")
    print(f"{YELLOW}Testing {len(accounts)} account(s)...{RESET}\n")
    
    alive = []
    dead = []
    
    for idx, account in enumerate(accounts, 1):
        print(f"{YELLOW}[{idx}/{len(accounts)}] {account['name']}...{RESET}", end=' ')
        
        if account.get('token'):
            token = account['token']
            try:
                test_response = requests.get(f'https://graph.facebook.com/v18.0/me?access_token={token}', timeout=10)
                if test_response.status_code == 200:
                    data = test_response.json()
                    if 'id' in data:
                        print(f"{GREEN}✓ Alive{RESET}")
                        alive.append(account)
                    else:
                        print(f"{RED}✗ Dead (Invalid token){RESET}")
                        dead.append(account)
                else:
                    print(f"{RED}✗ Dead (Status {test_response.status_code}){RESET}")
                    dead.append(account)
            except:
                print(f"{RED}✗ Dead (Connection error){RESET}")
                dead.append(account)
        else:
            token, _ = FacebookShare.get_token(account['cookie'])
            if token:
                try:
                    test_response = requests.get(f'https://graph.facebook.com/v18.0/me?access_token={token}', timeout=10)
                    if test_response.status_code == 200:
                        data = test_response.json()
                        if 'id' in data:
                            print(f"{GREEN}✓ Alive{RESET}")
                            alive.append(account)
                        else:
                            print(f"{RED}✗ Dead (Invalid){RESET}")
                            dead.append(account)
                    else:
                        print(f"{RED}✗ Dead (Status {test_response.status_code}){RESET}")
                        dead.append(account)
                except:
                    print(f"{RED}✗ Dead (Connection error){RESET}")
                    dead.append(account)
            else:
                print(f"{RED}✗ Dead (Cookie expired){RESET}")
                dead.append(account)
    
    print(f"\n{CYAN}=== RESULTS ==={RESET}")
    print(f"{GREEN}Alive: {len(alive)}{RESET}")
    print(f"{RED}Dead: {len(dead)}{RESET}")
    
    if dead:
        print(f"\n{YELLOW}Dead accounts:{RESET}")
        for acc in dead:
            print(f"  - {acc['name']}")
        
        confirm = input(f"\n{RED}Remove {len(dead)} dead account(s)? (y/n): {RESET}").lower()
        if confirm == 'y':
            AccountManager.save_accounts(alive)
            print(f"{GREEN}[✓] Removed {len(dead)} dead account(s)!{RESET}")
        else:
            print(f"{YELLOW}[!] No accounts removed{RESET}")
    else:
        print(f"\n{GREEN}[✓] All accounts are alive!{RESET}")
    
    input(f"\n{YELLOW}Press Enter to continue...{RESET}")

def main():
    while True:
        choice = main_menu()
        
        if choice == '1':
            AccountManager.extract_bulk()
            input(f"\n{YELLOW}Press Enter to continue...{RESET}")
        elif choice == '2':
            share_with_account()
        elif choice == '3':
            share_with_all()
        elif choice == '4':
            AccountManager.list_accounts()
            input(f"\n{YELLOW}Press Enter to continue...{RESET}")
        elif choice == '5':
            name = input(f"{CYAN}Account name: {RESET}").strip()
            cookie = input(f"{CYAN}Cookie: {RESET}").strip()
            if name and cookie:
                AccountManager.add_account(name, cookie)
            else:
                print(f"{RED}[✗] Name and cookie required{RESET}")
            input(f"\n{YELLOW}Press Enter to continue...{RESET}")
        elif choice == '6':
            remove_dead_accounts()
        elif choice == '0':
            print(f"\n{CYAN}Goodbye!{RESET}\n")
            break
        else:
            print(f"{RED}[✗] Invalid option{RESET}")
            input(f"\n{YELLOW}Press Enter to continue...{RESET}")

if __name__ == '__main__':
    try:
        main()
    except KeyboardInterrupt:
        print(f"\n\n{RED}[!] Interrupted{RESET}")
        sys.exit(0)
