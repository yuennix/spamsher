# SpamShare - Facebook Auto-Sharing Tool

## Overview

SpamShare is an automated Facebook post sharing application featuring a retro cyberpunk-themed web interface. The application enables users to share Facebook posts automatically using cookie-based or app-state authentication. It includes both a web-based Flask application and a standalone Termux script for mobile Android usage.

The project combines modern web technologies (Flask, Bootstrap, GSAP animations, Three.js) with Facebook Graph API integration to provide automated post sharing functionality with a visually striking terminal-style aesthetic.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

**UI Framework**: Bootstrap 5.3.0 with custom CSS overlay for cyberpunk/retro aesthetic
- **Design Pattern**: Glassmorphism and neumorphism effects with neon color scheme
- **Animation Libraries**: GSAP 3.12.2 for smooth animations and ScrollTrigger for parallax effects
- **3D Graphics**: Three.js 0.152.2 for interactive 3D background elements
- **Theme System**: Dual-theme support (light/dark mode) with localStorage persistence

**Rationale**: The combination of Bootstrap for responsive layout and custom cyberpunk styling creates a unique visual identity while maintaining usability. GSAP and Three.js add polish and interactivity without compromising performance.

### Backend Architecture

**Web Framework**: Flask 3.0.2
- **Session Management**: Flask sessions with configurable secret key
- **Routing Pattern**: Blueprint-style routing with template inheritance
- **Error Handling**: Flash messages for user feedback

**Core Components**:
1. **app.py**: Main Flask application with FacebookShare class for API interactions
2. **main.py**: Application entry point for both development and production
3. **cookie_generator.py**: Standalone module for generating Facebook authentication cookies from credentials

**Rationale**: Flask provides a lightweight, flexible framework suitable for this single-purpose application. The separation of concerns between authentication (cookie_generator) and sharing logic (FacebookShare class) allows for modularity and potential reuse.

### Authentication Mechanism

**Facebook Authentication**: Cookie-based authentication using Facebook's business.facebook.com endpoints
- Extracts access tokens from Facebook Business Manager pages
- Supports both manual cookie input and credential-based cookie generation
- Uses standard browser headers to mimic legitimate requests

**Security Considerations**: 
- Session secret stored as environment variable
- No persistent storage of credentials (cookies provided by user)
- Educational/demonstration purposes only (as noted in README)

### Facebook Graph API Integration

**Token Extraction**: 
- Scrapes access token from Facebook Business Manager HTML response
- Pattern: `EAAG` prefix followed by token string extraction via regex
- Headers include Chrome 107 user-agent and security headers for authenticity

**Post Sharing**:
- Uses Facebook Graph API endpoints (incomplete in provided code)
- Configurable share count and delay between shares
- Progress tracking and status updates

**Alternatives Considered**: Official Facebook SDK was likely avoided to maintain simplicity and reduce dependencies, though this approach is more fragile to Facebook UI changes.

### Deployment Architecture

**Production Server**: Gunicorn WSGI server
- Configuration: `--bind 0.0.0.0:$PORT --reuse-port`
- Supports concurrent requests with worker process reuse

**Target Platform**: Render.com free tier
- Build command: `pip install -r requirements.txt`
- Port binding via environment variable

**Rationale**: Gunicorn provides production-grade WSGI serving with minimal configuration. Render's free tier offers sufficient resources for this application's expected load.

### Termux/Mobile Support

**Standalone Script**: termux_share.py provides CLI-based alternative
- JSON-based account storage (accounts.json)
- ANSI color terminal interface with ASCII banner
- Multi-account bulk operations support

**Rationale**: Termux script enables Android users to run the tool without web hosting, useful for users who prefer command-line interfaces or have limited connectivity.

## External Dependencies

### Python Packages

**Core Framework**:
- `flask==3.0.2` - Web application framework
- `flask-sqlalchemy==3.1.1` - SQL toolkit (included but not actively used in provided code)
- `gunicorn==23.0.0` - Production WSGI server

**HTTP & Web Scraping**:
- `requests==2.31.0` - HTTP library for API calls and cookie generation
- `beautifulsoup4==4.12.2` - HTML parsing for cookie extraction
- `httpx` - Async HTTP client (listed but not used in provided code)
- `trafilatura` - Web scraping utility (listed but not used in provided code)

**Database**:
- `psycopg2-binary==2.9.9` - PostgreSQL adapter (listed but no database usage in provided code)

**Validation**:
- `email-validator==2.1.0.post1` - Email validation utilities

**Note**: Several dependencies appear unused in the current codebase (SQLAlchemy, PostgreSQL, httpx, trafilatura), suggesting either planned features or legacy inclusions that should be cleaned up.

### Frontend Libraries (CDN)

**UI Framework**:
- Bootstrap 5.3.0 - Responsive layout and components
- Font Awesome 6.4.0 - Icon library

**Animation & Effects**:
- GSAP 3.12.2 + ScrollTrigger - Advanced animations and scroll effects
- Three.js 0.152.2 - 3D graphics rendering

**Rationale**: CDN delivery reduces bundle size and leverages browser caching, though it introduces external dependencies that could affect offline functionality.

### Third-Party APIs

**Facebook Graph API**:
- Authentication endpoint: `https://business.facebook.com/content_management`
- Graph API endpoints: `https://b-graph.facebook.com` (referenced in attached Streamlit code)
- Token format: `EAAG` prefixed access tokens

**Authentication Flow**:
1. User provides Facebook cookie or credentials
2. Application extracts/generates access token from Business Manager
3. Token used to make Graph API calls for post sharing

**Rate Limiting**: Not implemented in current code; Facebook may impose rate limits

**Error Handling**: Basic try-catch blocks; cookie blocking detected but not gracefully handled

### Environment Configuration

**Required Variables**:
- `SESSION_SECRET` - Flask session encryption key (falls back to "dev-secret-key" if not set)

**Optional Variables**:
- `PORT` - Server port for Render deployment (defaults to 5000 in development)