#!/usr/bin/env python3
import os
import sys
import json
import time
import re
import requests
from datetime import datetime

# Color codes
RED = "\033[1;31m"
GREEN = "\033[1;32m"
YELLOW = "\033[1;33m"
BLUE = "\033[1;34m"
CYAN = "\033[1;36m"
MAGENTA = "\033[1;35m"
WHITE = "\033[1;37m"
RESET = "\033[0m"

BANNER = f"""{RED}
██╗    ██╗███████╗██╗   ██╗███╗   ██╗
██║    ██║██╔════╝╚██╗ ██╔╝████╗  ██║
██║ █╗ ██║█████╗   ╚████╔╝ ██╔██╗ ██║
██║███╗██║██╔══╝    ╚██╔╝  ██║╚██╗██║
╚███╔███╔╝███████╗   ██║   ██║ ╚████║
 ╚══╝╚══╝ ╚══════╝   ╚═╝   ╚═╝  ╚═══╝
{GREEN}════════════════════════════════════════════════════
{RESET}{CYAN}[ FACEBOOK TOOLS SUITE ]
{MAGENTA}[ Developed by WEYN DUMP ]
{GREEN}════════════════════════════════════════════════════
{RESET}"""

ACCOUNTS_FILE = "accounts.json"

class FacebookShare:
    @staticmethod
    def get_cookie_from_credentials(uid, password):
        """Extract cookie from uid|password"""
        try:
            session = requests.Session()
            headers = {
                'user-agent': "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36"
            }
            
            print(f"{YELLOW}[*] Getting login page...{RESET}")
            getlog = session.get(f'https://m.facebook.com/login/device-based/password/?uid={uid}&flow=login_no_pin')
            
            try:
                idpass = {
                    "lsd": re.search('name="lsd" value="(.*?)"', str(getlog.text)).group(1),
                    "jazoest": re.search('name="jazoest" value="(.*?)"', str(getlog.text)).group(1),
                    "uid": uid,
                    "next": "https://m.facebook.com/login/save-device/",
                    "flow": "login_no_pin",
                    "pass": password,
                }
            except:
                return None, "Failed to extract login form data"
            
            print(f"{YELLOW}[*] Attempting login...{RESET}")
            login = session.post("https://m.facebook.com/login/device-based/regular/login/?shbl=1", 
                               headers=headers, data=idpass, allow_redirects=False)
            
            cookies = session.cookies.get_dict()
            if "c_user" in cookies:
                cookie_str = ";".join([f"{k}={v}" for k, v in cookies.items()])
                return cookie_str, None
            elif "checkpoint" in cookies:
                return None, "Account checkpoint"
            else:
                return None, "Invalid username or password"
                
        except Exception as e:
            return None, f"Error: {str(e)}"
    
    @staticmethod
    def get_token(cookie):
        try:
            headers = {
                'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/107.0.0.0 Safari/537.36',
                'sec-ch-ua': '"Google Chrome";v="107", "Chromium";v="107", "Not=A?Brand";v="24"',
                'sec-ch-ua-mobile': '?0',
                'sec-ch-ua-platform': "Windows",
                'sec-fetch-dest': 'document',
                'sec-fetch-mode': 'navigate',
                'sec-fetch-site': 'none',
                'sec-fetch-user': '?1',
                'upgrade-insecure-requests': '1',
                'cookie': cookie
            }
            
            response = requests.get('https://business.facebook.com/content_management', headers=headers)
            data = response.text
            access_token = 'EAAG' + re.search('EAAG(.*?)","', data).group(1)
            return access_token, headers['cookie']
        except Exception as e:
            return None, None
    
    @staticmethod
    def share_post(cookie, post_url, token, count=1, delay=0):
        headers = {
            "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/107.0.0.0 Safari/537.36",
            "cookie": cookie,
            "accept": "application/json",
            "content-type": "application/x-www-form-urlencoded",
        }
        
        success_count = 0
        post_id = "uid_postid"
        try:
            post_parts = post_url.split("/")
            if len(post_parts) > 4:
                post_id = post_parts[-1]
        except:
            pass
            
        share_endpoint = f'https://graph.facebook.com/me/feed?access_token={token}'
        
        for i in range(count):
            print(f"{YELLOW}[{i+1}/{count}] Performing share {post_id}...{RESET}")
            
            if delay > 0 and i > 0:
                time.sleep(delay)
                
            try:
                post_data = {
                    'link': post_url,
                    'published': '0'
                }
                response = requests.post(share_endpoint, headers=headers, data=post_data)
                
                try:
                    data = response.json()
                except:
                    print(f"{RED}[✗] Invalid response from Facebook API{RESET}")
                    break
                    
                if 'id' in data:
                    success_count += 1
                    print(f"{GREEN}[✓] Share {i+1}/{count} successful!{RESET}")
                else:
                    print(f"{RED}[✗] Share failed: {str(data)}{RESET}")
                    break
                    
            except Exception as e:
                print(f"{RED}[✗] Error: {str(e)}{RESET}")
                break
                
        return success_count

class AccountManager:
    @staticmethod
    def load_accounts():
        if os.path.exists(ACCOUNTS_FILE):
            try:
                with open(ACCOUNTS_FILE, 'r') as f:
                    return json.load(f)
            except:
                return []
        return []
    
    @staticmethod
    def save_accounts(accounts):
        with open(ACCOUNTS_FILE, 'w') as f:
            json.dump(accounts, f, indent=2)
    
    @staticmethod
    def add_account(name, cookie):
        accounts = AccountManager.load_accounts()
        account = {
            'name': name,
            'cookie': cookie,
            'added_date': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            'status': 'active'
        }
        accounts.append(account)
        AccountManager.save_accounts(accounts)
        print(f"{GREEN}[✓] Account '{name}' added successfully!{RESET}")
    
    @staticmethod
    def list_accounts():
        accounts = AccountManager.load_accounts()
        if not accounts:
            print(f"{YELLOW}[!] No accounts stored.{RESET}")
            return
        
        print(f"\n{CYAN}=== STORED ACCOUNTS ==={RESET}")
        for idx, acc in enumerate(accounts, 1):
            status_color = GREEN if acc.get('status') == 'active' else RED
            print(f"{idx}. {acc['name']} | Added: {acc['added_date']} | {status_color}{acc.get('status', 'unknown')}{RESET}")
    
    @staticmethod
    def extract_bulk():
        print(f"\n{CYAN}Get Cookie{RESET}")
        print(f"{YELLOW}Paste uid|password (Enter twice):{RESET}")
        
        credentials = []
        print(f"{GREEN}Processing...{RESET}\n")
        
        while True:
            try:
                line = input().strip()
                if not line:
                    if credentials:
                        break
                    continue
                credentials.append(line)
            except:
                break
        
        if not credentials:
            print(f"{RED}[!] No credentials provided{RESET}")
            return
        
        success = 0
        failed = 0
        results = []
        
        for idx, cred in enumerate(credentials, 1):
            if '|' not in cred:
                print(f"{RED}[{idx}/{len(credentials)}] Invalid format{RESET}")
                failed += 1
                continue
            
            parts = cred.split('|')
            uid = parts[0].strip()
            password = parts[1].strip()
            
            print(f"{YELLOW}[{idx}/{len(credentials)}] {uid}...{RESET}", end=' ')
            
            cookie, error = FacebookShare.get_cookie_from_credentials(uid, password)
            
            if cookie:
                print(f"{GREEN}✓{RESET}")
                success += 1
                results.append({'uid': uid, 'cookie': cookie})
                AccountManager.add_account(f"Account_{uid}", cookie)
            else:
                print(f"{RED}✗ {error} (401){RESET}")
                failed += 1
        
        print(f"\n{GREEN}Total:{len(credentials)} Success:{success} Failed:{failed}{RESET}")
        
        if success > 0:
            save_choice = input(f"\n{CYAN}Save? (y/n): {RESET}").lower()
            if save_choice == 'y':
                filename = input(f"{CYAN}Filename (default: cookies.txt): {RESET}").strip() or "cookies.txt"
                with open(filename, 'w') as f:
                    for r in results:
                        f.write(f"{r['cookie']}\n")
                print(f"{GREEN}[✓] Saved {success} successful cookie(s) to {filename}{RESET}")
        elif failed > 0:
            print(f"{YELLOW}[!] No successful extractions to save{RESET}")

def clear():
    os.system('clear' if os.name != 'nt' else 'cls')

def main_menu():
    clear()
    print(BANNER)
    print(f"{CYAN}[1]{RESET} Get Cookie (Bulk Extract)")
    print(f"{CYAN}[2]{RESET} Share Post (Single Account)")
    print(f"{CYAN}[3]{RESET} Share Post (All Accounts)")
    print(f"{CYAN}[4]{RESET} List Accounts")
    print(f"{CYAN}[5]{RESET} Add Account (Manual Cookie)")
    print(f"{CYAN}[0]{RESET} Exit")
    
    choice = input(f"\n{GREEN}Select option: {RESET}").strip()
    return choice

def share_with_account():
    accounts = AccountManager.load_accounts()
    if not accounts:
        print(f"{RED}[!] No accounts available. Extract accounts first.{RESET}")
        input(f"\n{YELLOW}Press Enter to continue...{RESET}")
        return
    
    print(f"\n{CYAN}=== SELECT ACCOUNT ==={RESET}")
    for idx, acc in enumerate(accounts, 1):
        print(f"{idx}. {acc['name']}")
    
    try:
        selection = int(input(f"\n{GREEN}Select account number: {RESET}").strip())
        if selection < 1 or selection > len(accounts):
            print(f"{RED}[✗] Invalid selection{RESET}")
            return
        
        account = accounts[selection - 1]
        post_url = input(f"{CYAN}Post URL: {RESET}").strip()
        count = int(input(f"{CYAN}Share count: {RESET}").strip() or "1")
        delay = int(input(f"{CYAN}Delay (seconds): {RESET}").strip() or "0")
        
        print(f"\n{YELLOW}[*] Getting access token...{RESET}")
        token, cookie = FacebookShare.get_token(account['cookie'])
        
        if not token:
            print(f"{RED}[✗] Failed to get token. Account may be invalid.{RESET}")
            return
        
        print(f"{GREEN}[✓] Token obtained!{RESET}\n")
        
        success = FacebookShare.share_post(cookie, post_url, token, count, delay)
        print(f"\n{GREEN}[✓] Completed! {success}/{count} shares successful{RESET}")
        
    except ValueError:
        print(f"{RED}[✗] Invalid input{RESET}")
    
    input(f"\n{YELLOW}Press Enter to continue...{RESET}")

def share_with_all():
    accounts = AccountManager.load_accounts()
    if not accounts:
        print(f"{RED}[!] No accounts available.{RESET}")
        input(f"\n{YELLOW}Press Enter to continue...{RESET}")
        return
    
    post_url = input(f"{CYAN}Post URL: {RESET}").strip()
    count = int(input(f"{CYAN}Share count per account: {RESET}").strip() or "1")
    delay = int(input(f"{CYAN}Delay (seconds): {RESET}").strip() or "0")
    
    total_success = 0
    for idx, account in enumerate(accounts, 1):
        print(f"\n{CYAN}[*] Account {idx}/{len(accounts)}: {account['name']}{RESET}")
        
        token, cookie = FacebookShare.get_token(account['cookie'])
        if not token:
            print(f"{RED}[✗] Failed for {account['name']}{RESET}")
            continue
        
        success = FacebookShare.share_post(cookie, post_url, token, count, delay)
        total_success += success
    
    print(f"\n{GREEN}[✓] All done! Total: {total_success} shares{RESET}")
    input(f"\n{YELLOW}Press Enter to continue...{RESET}")

def main():
    while True:
        choice = main_menu()
        
        if choice == '1':
            AccountManager.extract_bulk()
            input(f"\n{YELLOW}Press Enter to continue...{RESET}")
        elif choice == '2':
            share_with_account()
        elif choice == '3':
            share_with_all()
        elif choice == '4':
            AccountManager.list_accounts()
            input(f"\n{YELLOW}Press Enter to continue...{RESET}")
        elif choice == '5':
            name = input(f"{CYAN}Account name: {RESET}").strip()
            cookie = input(f"{CYAN}Cookie: {RESET}").strip()
            if name and cookie:
                AccountManager.add_account(name, cookie)
            else:
                print(f"{RED}[✗] Name and cookie required{RESET}")
            input(f"\n{YELLOW}Press Enter to continue...{RESET}")
        elif choice == '0':
            print(f"\n{CYAN}Goodbye!{RESET}\n")
            break
        else:
            print(f"{RED}[✗] Invalid option{RESET}")
            input(f"\n{YELLOW}Press Enter to continue...{RESET}")

if __name__ == '__main__':
    try:
        main()
    except KeyboardInterrupt:
        print(f"\n\n{RED}[!] Interrupted{RESET}")
        sys.exit(0)
